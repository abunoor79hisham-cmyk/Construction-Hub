const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS and JSON parsing
app.use(cors());
// Set rich body limit to support Base64 file uploads in JSON format
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

// Paths
const DATA_DIR = __dirname;
const DB_PATH = path.join(DATA_DIR, 'db.json');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const DATA_JS_PATH = path.join(DATA_DIR, 'data.js');

// Ensure uploads folder exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Atomic database reader/writer helper
function readDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      return seedDatabase();
    }
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading database file:', err);
    return { groups: [], marks: {}, max_marks: {}, col_labels: {}, files: [] };
  }
}

function writeDB(data) {
  try {
    const tempPath = DB_PATH + '.tmp';
    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tempPath, DB_PATH); // Atomic replacement to prevent corruption
    return true;
  } catch (err) {
    console.error('Error writing to database file:', err);
    return false;
  }
}

// Seeding logic to migrate groups/students from data.js
function seedDatabase() {
  console.log('Initializing database...');
  const defaultDB = { groups: [], marks: {}, max_marks: {}, col_labels: {}, files: [] };

  if (fs.existsSync(DATA_JS_PATH)) {
    try {
      console.log('Seeding database from data.js...');
      const dataJsContent = fs.readFileSync(DATA_JS_PATH, 'utf8');
      // Simple extraction of window.DATA_GROUPS array using regex or custom parse
      const startIdx = dataJsContent.indexOf('[');
      const endIdx = dataJsContent.lastIndexOf(']');
      if (startIdx !== -1 && endIdx !== -1) {
        const jsonStr = dataJsContent.substring(startIdx, endIdx + 1);
        // Clean comments or potential trailing commas if any, though JSON.parse is strict
        // We evaluate it safely by replacing window.DATA_GROUPS
        // To be extremely safe and robust:
        const sandbox = {};
        const runInNewContext = (code) => {
          const fn = new Function('sandbox', `with(sandbox) { ${code} }`);
          const ctx = { window: {} };
          fn(ctx);
          return ctx.window.DATA_GROUPS;
        };
        const groups = runInNewContext(dataJsContent);
        if (Array.isArray(groups) && groups.length > 0) {
          defaultDB.groups = groups;
          console.log(`Successfully seeded ${groups.length} groups into database!`);
        }
      }
    } catch (err) {
      console.error('Failed to parse and seed data.js, starting empty:', err);
    }
  } else {
    console.log('data.js not found. Starting with empty database.');
  }

  writeDB(defaultDB);
  return defaultDB;
}

// Static files serving
app.use('/uploads', express.static(UPLOADS_DIR));
app.use(express.static(DATA_DIR));

// ==========================================
// API ENDPOINTS
// ==========================================

// Server Health / Status Check
app.get('/api/status', (req, res) => {
  res.json({ status: 'online', timestamp: Date.now(), database: 'JSON File Persistent' });
});

// Consolidated data load endpoint for persistent cache
app.get('/api/all-data', (req, res) => {
  const db = readDB();
  res.json({
    groups: db.groups || [],
    marks: db.marks || {},
    max_marks: db.max_marks || {},
    col_labels: db.col_labels || {}
  });
});

// 1. Groups Management
app.get('/api/groups', (req, res) => {
  const db = readDB();
  res.json(db.groups || []);
});

// Update groups (Admin only)
app.post('/api/groups', (req, res) => {
  const newGroups = req.body;
  if (!Array.isArray(newGroups)) {
    return res.status(400).json({ error: 'Invalid groups structure. Must be an array.' });
  }
  const db = readDB();
  db.groups = newGroups;
  writeDB(db);
  res.json({ success: true, count: newGroups.length });
});

// 2. Marks Management
app.get('/api/marks/:groupId', (req, res) => {
  const { groupId } = req.params;
  const db = readDB();
  res.json(db.marks[groupId] || {});
});

app.post('/api/marks/:groupId', (req, res) => {
  const { groupId } = req.params;
  const newMarks = req.body;
  
  const db = readDB();
  db.marks[groupId] = newMarks;
  
  if (writeDB(db)) {
    res.json({ success: true });
  } else {
    res.status(500).json({ error: 'Failed to write data' });
  }
});

// Reset marks for a specific group
app.delete('/api/marks/:groupId', (req, res) => {
  const { groupId } = req.params;
  const db = readDB();
  delete db.marks[groupId];
  writeDB(db);
  res.json({ success: true });
});

// 3. Configurations (Max marks & Custom columns)
app.get('/api/config/:groupId', (req, res) => {
  const { groupId } = req.params;
  const db = readDB();
  res.json({
    max_marks: db.max_marks[groupId] || {},
    col_labels: db.col_labels[groupId] || null
  });
});

app.post('/api/config/:groupId', (req, res) => {
  const { groupId } = req.params;
  const { max_marks, col_labels } = req.body;
  
  const db = readDB();
  
  if (max_marks) {
    db.max_marks[groupId] = max_marks;
  }
  if (col_labels) {
    db.col_labels[groupId] = col_labels;
  }
  
  if (writeDB(db)) {
    res.json({ success: true });
  } else {
    res.status(500).json({ error: 'Failed to write configurations' });
  }
});

// 4. Course Files Upload & Management
app.get('/api/files/:courseCode', (req, res) => {
  const { courseCode } = req.params;
  const db = readDB();
  const files = (db.files || []).filter(f => f.courseCode === courseCode);
  res.json(files);
});

app.get('/api/files/:courseCode/:category', (req, res) => {
  const { courseCode, category } = req.params;
  const db = readDB();
  const files = (db.files || []).filter(
    f => f.courseCode === courseCode && f.category === category
  );
  res.json(files);
});

// Base64 file upload endpoint
app.post('/api/files', (req, res) => {
  const { name, mime, content, category, courseCode, driveUrl } = req.body;
  
  if (!name || !content || !category || !courseCode) {
    return res.status(400).json({ error: 'Missing required upload parameters' });
  }
  
  try {
    let finalContentUrl = '';
    let storageFileName = '';

    // Handle binary content if it's sent as a base64 data URL
    if (content.startsWith('data:')) {
      const match = content.match(/^data:([^;]+);base64,(.+)$/);
      if (!match) {
        return res.status(400).json({ error: 'Invalid data URL format' });
      }
      
      const fileMime = match[1];
      const base64Data = match[2];
      const buffer = Buffer.from(base64Data, 'base64');
      
      // Clean safe unique filename
      const safeBaseName = name.replace(/[^a-zA-Z0-9.-]/g, '_');
      storageFileName = `${Date.now()}_${safeBaseName}`;
      const filePath = path.join(UPLOADS_DIR, storageFileName);
      
      // Save binary file to filesystem
      fs.writeFileSync(filePath, buffer);
      finalContentUrl = `/uploads/${storageFileName}`;
    } else {
      // For simple txt files or backup text
      const safeBaseName = name.replace(/[^a-zA-Z0-9.-]/g, '_');
      storageFileName = `${Date.now()}_${safeBaseName}`;
      const filePath = path.join(UPLOADS_DIR, storageFileName);
      fs.writeFileSync(filePath, content, 'utf8');
      finalContentUrl = `/uploads/${storageFileName}`;
    }

    const fileId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const newFile = {
      id: fileId,
      name: name,
      mime: mime,
      content: finalContentUrl, // Replaces base64 payload with a clean static URL!
      added: Date.now(),
      category: category,
      courseCode: courseCode,
      driveUrl: driveUrl || null
    };

    const db = readDB();
    if (!db.files) db.files = [];
    db.files.push(newFile);
    
    if (writeDB(db)) {
      res.json(newFile);
    } else {
      res.status(500).json({ error: 'Failed to update file catalog' });
    }
  } catch (err) {
    console.error('File saving error:', err);
    res.status(500).json({ error: 'Server error during file write' });
  }
});

// Update drive URL for a file
app.post('/api/files/drive', (req, res) => {
  const { fileId, driveUrl } = req.body;
  if (!fileId || !driveUrl) {
    return res.status(400).json({ error: 'Missing fileId or driveUrl' });
  }
  
  const db = readDB();
  const file = (db.files || []).find(f => f.id === fileId);
  if (file) {
    file.driveUrl = driveUrl;
    writeDB(db);
    res.json({ success: true, file });
  } else {
    res.status(404).json({ error: 'File not found' });
  }
});

// Delete a file
app.delete('/api/files/:fileId', (req, res) => {
  const { fileId } = req.params;
  const db = readDB();
  
  const fileIdx = (db.files || []).findIndex(f => f.id === fileId);
  if (fileIdx === -1) {
    return res.status(404).json({ error: 'File not found' });
  }
  
  const file = db.files[fileIdx];
  
  // Remove file from filesystem if it exists locally
  if (file.content.startsWith('/uploads/')) {
    const fileName = file.content.replace('/uploads/', '');
    const filePath = path.join(UPLOADS_DIR, fileName);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {
        console.error(`Failed to delete physical file ${filePath}:`, err);
      }
    }
  }
  
  db.files.splice(fileIdx, 1);
  writeDB(db);
  res.json({ success: true });
});

// Delete all files in a specific category for a course
app.delete('/api/files-clear/:courseCode/:category', (req, res) => {
  const { courseCode, category } = req.params;
  const db = readDB();
  
  if (!db.files) db.files = [];
  
  // Keep files that do not match
  const filesToDelete = db.files.filter(f => f.courseCode === courseCode && f.category === category);
  const filesToKeep = db.files.filter(f => !(f.courseCode === courseCode && f.category === category));
  
  // Delete physical files
  filesToDelete.forEach(file => {
    if (file.content.startsWith('/uploads/')) {
      const fileName = file.content.replace('/uploads/', '');
      const filePath = path.join(UPLOADS_DIR, fileName);
      if (fs.existsSync(filePath)) {
        try {
          fs.unlinkSync(filePath);
        } catch (err) {
          console.error(`Failed to delete physical file ${filePath}:`, err);
        }
      }
    }
  });
  
  db.files = filesToKeep;
  writeDB(db);
  res.json({ success: true, count: filesToDelete.length });
});

// Catch-all route to serve the Hub homepage
app.get('*', (req, res) => {
  res.sendFile(path.join(DATA_DIR, 'index.html'));
});

// Start listening
app.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`Construction Department Portal running dynamically!`);
  console.log(`Local Access: http://localhost:${PORT}`);
  console.log(`==================================================`);
});
